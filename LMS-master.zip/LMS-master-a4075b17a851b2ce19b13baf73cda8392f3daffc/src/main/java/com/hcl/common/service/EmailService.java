package com.hcl.common.service;

public interface EmailService {

}
