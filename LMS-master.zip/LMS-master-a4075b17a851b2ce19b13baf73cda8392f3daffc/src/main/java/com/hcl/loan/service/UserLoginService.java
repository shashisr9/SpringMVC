package com.hcl.loan.service;

import com.hcl.loan.model.User;

public interface UserLoginService {

	User validateLoginUser(User user);
}
