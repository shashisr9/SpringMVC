package com.hcl.loan.config;

public class B extends A{

	public B()	{
		
	}
	
}
