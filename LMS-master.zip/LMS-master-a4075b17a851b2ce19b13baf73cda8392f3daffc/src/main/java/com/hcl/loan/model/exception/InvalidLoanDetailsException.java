package com.hcl.loan.model.exception;

public class InvalidLoanDetailsException extends RuntimeException {

}
