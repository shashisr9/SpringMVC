package com.hcl.loan.dao;

public interface RepaymentDAO {

}
