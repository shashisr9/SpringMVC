package com.hcl.loan.constants;

import com.hcl.loan.config.*;

public class C {

	A a = new A();
}
