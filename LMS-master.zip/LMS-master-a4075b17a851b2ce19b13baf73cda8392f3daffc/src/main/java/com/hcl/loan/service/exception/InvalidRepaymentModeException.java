package com.hcl.loan.service.exception;

public class InvalidRepaymentModeException extends Exception {

}
