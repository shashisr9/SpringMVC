package com.hcl.loan.dao;

import com.hcl.loan.model.User;

public interface UserLoginDAO {

	User validateLoginUser(User user);

}
