package com.hcl.loan.service;

public interface RepaymentService {

}
